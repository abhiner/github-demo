package com.cls.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cls.entity.Response;
import com.cls.entity.Student;
import com.cls.service.StudentService;

@RestController
public class StudentController {
	@Autowired 
	private StudentService service;
	
	
	@GetMapping("/hello")
	public String Hello() {
		return "Hello Abhishek";
	}
	
	@GetMapping("/student/allStudents")
	 public List<Student> GetAllStudents() {
		 return service.findAll();
	 }
	
	@GetMapping("/student/{id}")
	public Response GetStudent(@PathVariable int id) {
		Response response=new Response();
		Student student = service.findById(id);
		if(student==null) {
			response.setError("Student not found for id :" +id);
		}
		else {
			List<Student> students = new ArrayList<Student>();
			students.add(student);
			response.setStudents(students);
		}
		return response;
	}
	
	@PostMapping("/student/addStudent")
	public Student addStudent(@RequestBody Student student) {
		service.save(student);
		return student;
	}
	
	@DeleteMapping("/student/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable int id) {
		Student student = service.findById(id);
		if(student==null) {
			return new ResponseEntity<>("Error : Id not present", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else {
			service.deleteById(id);
			return new ResponseEntity<>("Student with id "+id +" deleted successfully", HttpStatus.OK);
		}
		
	}
	
	@PutMapping("/student/{id}")
	public ResponseEntity<String> updateStudent(@PathVariable int id, @RequestBody Student student) {
		Student stud=service.findById(id);
		if(stud==null) {
			return new ResponseEntity<>("Error : Id not present", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else {
			service.update(id, student);
			return new ResponseEntity<>("Student with id "+id +" updated successfully",HttpStatus.OK);
		}
		
	}
	
}
