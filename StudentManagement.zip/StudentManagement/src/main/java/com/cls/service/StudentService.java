package com.cls.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cls.dao.StudentDao;
import com.cls.entity.Student;

@Service
public class StudentService {
	private static List<Student> students=new ArrayList<>();  
	
	static  
	{  
	//adding users to the list  
	students.add(new Student(1, "John", "Comp"));  
	students.add(new Student(2, "Robert", "Electrical"));  
	students.add(new Student(3, "Adam", "E&TC"));  
	students.add(new Student(4, "Andrew", "Mechanical"));  
	students.add(new Student(5, "Jack", "Civil"));  
	}  

	
	public List<Student> findAll()  
	{  
	return students;  
	}  
	
	public Student findById(int id) {
		for(Student student:students) {
			if(student.getId()==id) {
				return student;
			}
		}
		return null;
	}
	
	public void save(Student stud) {
		students.add(stud);
	}
	
	public Student deleteById(int id) {
		for(Student student:students) {
			if(student.getId()==id) {
				students.remove(student);
				return student;
			}
		}
		return null;
	}
	
	public Student update(int id,Student stud) {
		Student s=findById(id);
		s.setName(stud.getName());
		s.setDepartment(stud.getDepartment());
		return s;
	}
}
