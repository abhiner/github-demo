package com.cls.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cls.entity.Student;

@Repository
public interface StudentDao extends CrudRepository<Student, Integer> {
	@Query(value = "select id, name, department from student", nativeQuery = true)
	List<Student> findAll();
}
