package com.cls.entity;

public class Error {

}
