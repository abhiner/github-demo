package com.cls.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Response {
	private List<Student> students;
	private String error="";
	private Map<String, Object> response=new HashMap<String, Object>();
	
	public void setStudents(List<Student> students) {
		response.put("students",students);
	}
	
	public void setError(String error) {
		response.put("error",error);
		
	}

	public Map<String, Object> getResponse() {
		return response;
	}

	
	
}
